var sanitizeHtml = require('sanitize-html');
 
exports.handler = async (event) => {
    return {
          cleanDescription: sanitizeHtml(event.input.description)
    };
}
